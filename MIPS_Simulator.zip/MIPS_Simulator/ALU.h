#ifndef ALU_H_
#   define ALU_H_
#   include "MIPS.h"
#   define PC_REGNUM 32
#   define HI_REGNUM 33
#   define LO_REGNUM 34

union instructionRegiser{
    unsigned int I;
    struct RFormat{
        unsigned int funct : 6;
        unsigned int sh : 5;
        unsigned int rd : 5;
        unsigned int rt : 5;
        unsigned int rs : 5;
        unsigned int opcode : 6;
    }RI;
}IR;  //Instruction Fatch용

unsigned int invertEndian(unsigned int inVal);//little->big endian으로 변환
unsigned int ALU(unsigned int inst,unsigned int PC);////메모리 읽기

#endif