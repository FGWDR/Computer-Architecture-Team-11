#include "ALU.h"

unsigned int invertEndian(unsigned int inVal)//little to big endian
{
    inVal=((inVal>>24)&0xff)|((inVal<<8)&0xff0000)|((inVal>>8)&0xff00)|((inVal<<24)&0xff000000);
    return inVal;
}

unsigned int ALU(unsigned int inst, unsigned int PC)//0xaabbccdd
{
    IR.I=invertEndian(inst);//big -> little
    PC=RegAccess(PC_REGNUM,0, 0);
    unsigned int MSB;
    unsigned int temp;
    unsigned int hi;
    unsigned int lo;
    unsigned int result;
    unsigned long multiResult;
    //-------------------------------------------
    if(IR.RI.opcode==0)//R 명령어
    {
        switch(IR.RI.funct)
        {
            //shift operations-----------------------------
            case 0://sll: rt=start, rd=dest, sh=amount
                RegAccess(IR.RI.rd,RegAccess(IR.RI.rt,0,0)<<IR.RI.sh,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 2://srl: 
                RegAccess(IR.RI.rd,RegAccess(IR.RI.rt,0,0)>>IR.RI.sh,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 3://sra: MSB 복사, 나머지 오른쪽으로 shift
                MSB= RegAccess(IR.RI.rt,0,0) & 0x80000000;//0,1
                temp=RegAccess(IR.RI.rt,0,0);
                for(int i=0; i<IR.RI.sh; i++)
                {
                    temp = (temp >> 1) + MSB;
                }
                RegAccess(IR.RI.rt,temp,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 8://Jump register: jr $ra
                PC=RegAccess(IR.RI.rs,0,0);
                RegAccess(PC_REGNUM, PC, 1);
                break;
            case 12://syscall
                printf("Inst: syscall\n");
                RegAccess(PC_REGNUM, PC+4, 1);
                return 0;
            case 16://mfhi rd: Move from Hi
                RegAccess(IR.RI.rd,(RegAccess(HI_REGNUM, 0, 0)),1);
                RegAccess(PC_REGNUM,PC+4,1);
                break;
            case 18://mflo rd: Move from Lo
                RegAccess(IR.RI.rd,(RegAccess(LO_REGNUM, 0, 0)),1);
                RegAccess(PC_REGNUM,PC+4,1);
                break;
            case 24://mult: multiply rs,rt: MULT rs, rt; HI:LO = rs * rt (signed)
                multiResult=RegAccess(IR.RI.rs,0,0)*RegAccess(IR.RI.rt,0,0);
                hi=multiResult>>32;//64bit중 상위 32bit
                lo=multiResult & 0xffffffff;//64bit중 하위 32bit
                RegAccess(HI_REGNUM, hi, 1);
                RegAccess(LO_REGNUM, lo, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
                //--------------------------
            case 32://add rd = rs + rt
                result=RegAccess(IR.RI.rs,0,0)+RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 34://sub
                result=RegAccess(IR.RI.rs,0,0)-RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 36://and
                result=RegAccess(IR.RI.rs,0,0)&RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 37:// or
                result=RegAccess(IR.RI.rs,0,0)|RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 38://xor
                result=RegAccess(IR.RI.rs,0,0)^RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 39://nor
                result=RegAccess(IR.RI.rs,0,0)|RegAccess(IR.RI.rt,0,0);
                RegAccess(IR.RI.rd,~result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 42://slt: set less than: if(rs<rt) rd = 1; else rd = 0;
                if(RegAccess(IR.RI.rs,0,0)<RegAccess(IR.RI.rt,0,0))
                {
                    RegAccess(IR.RI.rd,1,1);
                }
                else
                {
                    RegAccess(IR.RI.rd,0,1);
                }
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            default:// default
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
        }
    }
    else//opcode가 000_000이 아니므로 opcode 명령어 찾기
    {
        //I format instructions
        unsigned int imm = IR.I & 0x0000ffff;
        unsigned int address = IR.I & 0x03ffffff;
        unsigned int immUp;
        unsigned int L;
        unsigned int MEMout;
        if((imm>>15)==1) imm=imm|0xffff0000;

        switch(IR.RI.opcode)
        {
        //branch 명령어-----------------------------------------------------
            case 1://bltz rs,L: branch less than 0
                L=PC+(imm<<2);
                if(RegAccess(IR.RI.rs,0,0) < 0)
                {
                    RegAccess(PC_REGNUM, L, 1);
                }
                else{
                    RegAccess(PC_REGNUM, PC+4, 1);
                }
                break;
            case 2://j L: jump-> address00+4 : program counter
                L=(PC>>28)|(address<<2);
                //다음 처리될 명령어는 L이 되어야한다.
                RegAccess(PC_REGNUM, L, 1);
                break;
            case 3://jal L: jump and link
                L=(PC>>28)|(address<<2);
                RegAccess(31,PC+4,1);
                RegAccess(PC_REGNUM,L, 1);//다음 주소값 명령어를 레지스터에 저장
                break;
            case 4://beq rs, rt, L: branch equal
                L=PC+(imm<<2);
                if(RegAccess(IR.RI.rs,0,0) == RegAccess(IR.RI.rt,0,0))
                {
                    RegAccess(PC_REGNUM,L, 1);
                }
                else
                {
                    RegAccess(PC_REGNUM, PC+4, 1);
                }
                break;
            case 5://bne rs, rt, L: Branch not equal
                L=PC+(imm<<2);
                if(RegAccess(IR.RI.rs,0,0) != RegAccess(IR.RI.rt,0,0))
                {
                    RegAccess(PC_REGNUM,L, 1);
                }
                else
                {
                    RegAccess(PC_REGNUM, PC+4, 1);
                }
                break;
        //immediate-------------------------------------------------------------
            case 8://addi rt,rs, imm: ADD immediate
                result=RegAccess(IR.RI.rs,0,0)+imm;
                RegAccess(IR.RI.rt,result,1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 10://slti rt,rs, imm: set less than immediate
                if(RegAccess(IR.RI.rs,0,0) < imm)
                {
                    RegAccess(IR.RI.rt, 1, 1);//$s1=1
                }
                else
                {
                    RegAccess(IR.RI.rt, 0, 1);//$s1=0
                }
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 12:// andi rt, rs, imm: AND immediate
                result=RegAccess(IR.RI.rs,0,0)&imm;
                RegAccess(IR.RI.rt, result, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 13://ori rt, rs, imm: OR immediate
                result=RegAccess(IR.RI.rs,0,0)|imm;
                RegAccess(IR.RI.rt, result, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 14://xor rt, rs, imm: XOR immediate
                result=RegAccess(IR.RI.rs,0,0)^imm;
                RegAccess(IR.RI.rt, result, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 15:// lui rt, imm: load upper immediate// 상위 16bit에 imm값 넣고 뒤 16bit는 0으로 둔다.
                immUp = imm << 16;
                RegAccess(IR.RI.rt, immUp, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 32://lb rt, imm(rs): load byte
                MEMout=invertEndian(MemAccess(RegAccess(IR.RI.rs,0,0)+imm, 0, 0, 0));
                if(((MEMout&0xa0)>>7)==1) MEMout=MEMout|0xffffff00;
                RegAccess(IR.RI.rt, MEMout, 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 35://lw rt, imm(rs): load word
                RegAccess(IR.RI.rt, invertEndian(MemAccess(RegAccess(IR.RI.rs,0,0)+imm, 0, 0, 2)), 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 36://lbu rt, imm(rs): load byte unsigned
                RegAccess(IR.RI.rt, invertEndian(MemAccess(RegAccess(IR.RI.rs,0,0)+imm, 0, 0, 0)), 1);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 40://sb rt, imm(rs): store byte/ reg->mem
                MemAccess(RegAccess(IR.RI.rs,0,0)+imm, invertEndian(RegAccess(IR.RI.rt, 0, 0)), 1, 0);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            case 43://sw rt, im(rs): store word
                MemAccess(RegAccess(IR.RI.rs,0,0)+imm, invertEndian(RegAccess(IR.RI.rt, 0, 0)), 1, 2);
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
            default:
                RegAccess(PC_REGNUM, PC+4, 1);
                break;
        }
    }

    return 1;
}
