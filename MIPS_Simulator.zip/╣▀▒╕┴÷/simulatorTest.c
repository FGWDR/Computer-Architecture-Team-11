#include "interface.h"

int main(void){
    return interface();
}